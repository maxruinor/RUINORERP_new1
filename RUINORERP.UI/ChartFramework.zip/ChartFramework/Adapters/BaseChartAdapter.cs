﻿using RUINORERP.UI.ChartFramework.Data.Builders;
using RUINORERP.UI.ChartFramework.Data.Interfaces;
using RUINORERP.UI.ChartFramework.Models;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Adapters
{
    // Data/Adapters/BaseChartAdapter.cs
    public abstract class BaseChartAdapter : IChartDataSource
    {
        protected readonly ISqlSugarClient _db;
        protected readonly SqlDynamicBuilder _sqlBuilder = new();

        protected BaseChartAdapter(ISqlSugarClient db) => _db = db;

        public abstract IEnumerable<MetricConfig> GetDimensions();
        IEnumerable<DimensionConfig> IChartDataSource.GetDimensions()
        {
            throw new NotImplementedException();
        }
        public abstract IEnumerable<MetricConfig> GetMetrics();
        public async Task<ChartDataSet> GetDataAsync(ChartRequest request)
        {
            //var (sql, parameters) = _sqlBuilder.BuildQuery(request);
           // var rawData = await _db.Ado.SqlQueryAsync<dynamic>(sql, parameters);

           // var dataSet = TransformToChartDataSet(rawData, request);
            //dataSet.RawData = rawData.Select(x => (IDictionary<string, object>)x).ToList();

            //return dataSet;

            return null;
        }

        protected abstract ChartDataSet TransformToChartDataSet(List<dynamic> rawData, ChartRequest request);

    
    }
}
