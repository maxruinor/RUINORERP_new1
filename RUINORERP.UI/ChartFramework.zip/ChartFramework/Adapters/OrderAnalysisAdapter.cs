﻿using RUINORERP.UI.ChartFramework.Core;
using RUINORERP.UI.ChartFramework.Data.Abstract.ChartFramework.Data.Abstract;
using RUINORERP.UI.ChartFramework.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ValueType = RUINORERP.UI.ChartFramework.Core.ValueType;

namespace RUINORERP.UI.ChartFramework.Adapters
{
    // Adapters/OrderAnalysisAdapter.cs
    public class OrderAnalysisAdapter : ChartDataSourceBase
    {
        public override async Task<ChartDataSet> GetDataAsync(ChartRequest request)
        {
            var query = BuildQuery(request);
            var rawData = await ExecuteQuery(query);

            return new ChartDataSet
            {
                Title = "订单分析报告",
                MetaData = new ChartMetaData
                {
                    PreferredVisualType = DetectChartType(request),
                    ValueType = ValueType.Currency,
                    StackMode = request.Dimensions.Count > 1 ? StackMode.Normal : StackMode.None,
                    CategoryLabels = await GetCategoryLabels(query, request)
                },
                Series = await BuildSeries(query, request),
                RawRecords = rawData.Select(r => new DynamicRecord(r)).ToList()
            };
        }

        private ChartType DetectChartType(ChartRequest request)
        {
            return request.Metrics.Count > 3 ? ChartType.Line : ChartType.Column;
        }
    }
}
