﻿using LiveChartsCore.Kernel.Sketches;
using RUINORERP.UI.ChartFramework.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Controls
{
    // Controls/ThreadSafeChartUpdater.cs
    public class ThreadSafeChartUpdater
    {
        private readonly SynchronizationContext _syncContext;
        private readonly IChartView _chart;

        public ThreadSafeChartUpdater(IChartView chart)
        {
            _syncContext = SynchronizationContext.Current
                ?? throw new InvalidOperationException("需要UI线程初始化");
            _chart = chart;
        }

        public void UpdateData(ChartDataSet newData)
        {
            if (SynchronizationContext.Current == _syncContext)
            {
                DirectUpdate(newData);
            }
            else
            {
                _syncContext.Post(_ => DirectUpdate(newData), null);
            }
        }

        private void DirectUpdate(ChartDataSet data)
        {
            // 确保在UI线程执行的更新逻辑
            _chart.Series = data.Series.ToArray();
            _chart.Title.Text = data.Title;
            // ...其他属性更新
        }
    }
}
