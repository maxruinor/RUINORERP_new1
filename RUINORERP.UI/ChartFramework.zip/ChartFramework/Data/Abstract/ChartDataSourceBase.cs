﻿using RUINORERP.Business.CommService;
using RUINORERP.Model;
using RUINORERP.UI.ChartAnalyzer;
using RUINORERP.UI.ChartFramework.Core;
using RUINORERP.UI.ChartFramework.Data.Interfaces;
using RUINORERP.UI.ChartFramework.Models;
using RUINORERP.UI.ChartFramework.Models.ChartFramework.Core.Models;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Data.Abstract
{
    // Data/Abstract/ChartDataSourceBase.cs
    namespace ChartFramework.Data.Abstract
    {

        // 增强版数据源基类
        public abstract class ChartDataSourceBase : IChartDataSource
        {
            //public abstract Task<ChartDataSet> GetDataAsync(ChartRequest request);

            public virtual async Task<ChartDataSet> GetDataAsync(ChartRequest request)
            {
                //var (sql, parameters) = BuildQuery(request);
                //var rawData = await ExecuteQueryAsync(sql, parameters);
                //return TransformData(rawData, request);

                //实际要子类来实现
                return await Task.FromResult(new ChartDataSet());
            }


            protected virtual (string sql, SugarParameter[] parameters) BuildQuery(ChartRequest request)
            {
                // 动态SQL构建逻辑
                var sqlBuilder = new SqlBuilder()
                    .WithTimeRange(request)
                    .WithDimensions(request.Dimensions)
                    .WithMetrics(request.Metrics)
                    .WithFilters(request.Filters);
                return sqlBuilder.Build();
            }


            protected abstract ChartDataSet TransformData(List<dynamic> rawData, ChartRequest request);

            //public virtual IEnumerable<DimensionConfig> GetAvailableDimensions()
            //{
            //    return new List<DimensionConfig>
            //    {
            //        new("Created_at", "创建时间", DimensionType.DateTime),
            //        new("Region", "区域", DimensionType.String)
            //    };
            //}
            public virtual IEnumerable<DimensionConfig> GetDimensions()
            {
                //return new List<DimensionConfig>
                //{
                //    new DimensionConfig("Employee_ID", "业务员", DimensionType.String),
                //    new DimensionConfig("Region_ID", "区域", DimensionType.String),
                //    new DimensionConfig("Created_at", "创建时间", DimensionType.DateTime)
                //};

                return new List<DimensionConfig>();
            }

            public virtual IEnumerable<MetricConfig> GetMetrics()
            {
                return new List<MetricConfig>();
            }
            /*
            public ChartDataSet TransformToChartDataSet(List<dynamic> data, ChartRequest request)
            {
                var chartData = new ChartDataSet();

                //修改查询结果的值
                foreach (var item in data)
                {
                    if (request.TimeGroupType == TimeRangeType.Monthly)
                    {
                        item.TimeGroup = item.TimeGroup + "月";
                    }
                    if (request.TimeGroupType == TimeRangeType.Weekly)
                    {
                        item.TimeGroup = item.TimeGroup + "周";
                    }
                }

                // 1. 处理时间维度作为X轴标签
                chartData.Labels = data.Select(x => (string)x.TimeGroup.ToString()).Distinct().OrderBy(x => x).ToList().ToArray();

                // 2. 处理其他维度作为系列
                if (request.Dimensions.Any())
                {
                    var seriesGroups = data
                        .GroupBy(x => string.Join(",", x.业务员))
                        .ToList();

                    foreach (var group in seriesGroups)
                    {
                        string seriesName = group.Key.ToString();
                        tb_Employee Employee = BizCacheHelper.Instance.GetEntity<tb_Employee>(seriesName.ToLong());
                        if (Employee != null)
                        {
                            seriesName = Employee.Employee_Name;
                        }

                        var series = new ChartSeries
                        {
                            Name = seriesName,
                            Values = new List<double>()
                        };

                        // 填充每个时间点的值
                        foreach (var label in chartData.Labels)
                        {
                            var value = group.FirstOrDefault(x => (string)(x.TimeGroup.ToString()) == label)?.Count ?? 0;
                            series.Values.Add((double)value);
                        }

                        chartData.Series.Add(series);
                    }
                }
                else
                {
                    // 没有其他维度时，只显示一个系列
                    var series = new ChartSeries
                    {
                        Name = "客户数量",
                        Values = new List<double>()
                    };

                    foreach (var label in chartData.Labels)
                    {
                        var value = data.FirstOrDefault(x => (string)(x.TimeGroup.ToString()) == label)?.Count ?? 0;
                        series.Values.Add((double)value);
                    }

                    chartData.Series.Add(series);
                }

                return chartData;
            }
            */



            protected readonly ISqlSugarClient _db;

            protected ChartDataSourceBase(ISqlSugarClient db)
            {
                _db = db;
            }





            public virtual IEnumerable<MetricConfig> GetAvailableMetrics()
            {
                return new List<MetricConfig>
            {
                new("Count", "数量", MetricType.Count,ColorHelper.HexToSKColor("#4CAF50")),
                new("Amount", "金额", MetricType.Sum, ColorHelper.HexToSKColor("#2196F3"))
            };
            }

            protected virtual ISugarQueryable<T> ApplyFilters<T>(
                ISugarQueryable<T> query,
                List<QueryFilter> filters)
            {
                foreach (var filter in filters)
                {
                    query = filter.Operator switch
                    {
                        ">" => query.Where($"{filter.Field} > @0", filter.Value),
                        "<" => query.Where($"{filter.Field} < @0", filter.Value),
                        _ => query.Where($"{filter.Field} = @0", filter.Value)
                    };
                }
                return query;
            }
        }

 

    }
}
