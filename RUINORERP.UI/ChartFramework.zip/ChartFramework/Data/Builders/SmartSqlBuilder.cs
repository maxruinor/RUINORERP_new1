﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Data.Builders
{
    internal class SmartSqlBuilder
    {
    }
}
