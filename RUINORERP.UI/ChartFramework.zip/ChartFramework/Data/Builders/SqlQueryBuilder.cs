﻿using RUINORERP.UI.ChartFramework.Data.Abstract.ChartFramework.Data.Abstract;
using RUINORERP.UI.ChartFramework.Models;
using SqlSugar;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Data.Builders
{
    // Data/Builders/SqlQueryBuilder.cs
    public class SqlQueryBuilder
    {

        private readonly ChartRequest _request;
        private readonly List<SugarParameter> _parameters = new();

        public SqlQueryBuilder(ChartRequest request)
        {
            _request = request;
        }

        //public (string Sql, SugarParameter[] Parameters) Build()
        //{
        //    var select = BuildSelect();
        //    var from = BuildFrom();
        //    var where = BuildWhere();
        //    var groupBy = BuildGroupBy();

        //    var sql = $"{select} {from} {where} {groupBy}";
        //    return (sql, _parameters.ToArray());
        //}

        private string BuildSelect()
        {
            var fields = new List<string>();

            // 添加分组字段
            fields.AddRange(_request.Dimensions.Select(d => $"{d} AS {d.Replace(".", "_")}"));

            // 添加聚合指标
            foreach (var metric in _request.Metrics)
            {
                fields.Add($"{GetAggregateExpression(metric)} AS {metric}");
            }

            return $"SELECT {string.Join(", ", fields)}";
        }

        private string GetAggregateExpression(string metric)
        {
            // 根据配置返回COUNT(1)或SUM(Amount)等
            return metric switch
            {
                "Count" => "COUNT(1)",
                "Amount" => "SUM(Amount)",
                _ => $"SUM({metric})"
            };
        }

        // 其他构建方法...
    }

}
