﻿using RUINORERP.UI.ChartFramework.Models.ChartFramework.Core.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Models
{
    public class ChartInteraction
    {
        public List<ChartContextMenuItem> ContextMenuItems { get; } = new();

        public void AddMenuItem(string text, Action<ChartDataSet> action)
        {
            ContextMenuItems.Add(new ChartContextMenuItem(text, action));
        }
    }
    public record ChartContextMenuItem(string Text, Action<ChartDataSet> Action);
}
