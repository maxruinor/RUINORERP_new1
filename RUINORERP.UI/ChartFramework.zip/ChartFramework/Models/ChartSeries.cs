﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Models
{
    // Core/Models/ChartSeries.cs
    namespace ChartFramework.Core.Models
    {

        /// <summary>
        /// 图表数据系列（增强版）
        /// </summary>
        public class ChartSeries
        {

            /// <summary>
            /// 系列名称
            /// </summary>
            public string Name { get; set; }

            /// <summary>
            /// 数据值集合
            /// </summary>
            public List<double> Values { get; set; } = new List<double>();

            /// <summary>
            /// 各数据点的独立标签（主要用于饼图）
            /// </summary>
            public string[] DataPointLabels { get; set; }

            /// <summary>
            /// 各数据点的原始值（存储计算前的原始值）
            /// </summary>
            public List<double> RawValues { get; set; } = new List<double>();

            /// <summary>
            /// 系列所属的分组（用于堆叠/分组图表）
            /// </summary>
            public string GroupName { get; set; }

            /// <summary>
            /// 系列颜色（可选）
            /// </summary>
            public string ColorHex { get; set; }

            /// <summary>
            /// 是否为虚线样式（仅折线图有效）
            /// </summary>
            public bool IsDashed { get; set; }




            // 在ChartSeries中添加
            public double InnerRadius { get; set; } // 内半径（用于环形图）
            public double Pushout { get; set; } // 扇形突出距离
         
            public string Id { get; } = Guid.NewGuid().ToString();

   
            public int AxisIndex { get; set; }
       
            public List<string> DataLabels { get; set; } = new();
            public SeriesVisualStyle Style { get; set; } = new();
        }

        public class LineChartSeries : ChartSeries
        { // 在ChartSeries中添加
            public bool ShowMarkers { get; set; } = true; // 是否显示数据点标记
            public double LineSmoothness { get; set; } = 0.5; // 线条平滑度
        }
        public class ColumnChartSeries : ChartSeries
        {
            // 在ChartSeries中添加
            public double ColumnWidth { get; set; } = 0.8; // 柱宽比例（0-1）
            public bool IsStackedSeries { get; set; } // 是否参与堆叠
        }
        public class PieChartSeries : ChartSeries
        {
            // 在ChartSeries中添加
            public double InnerRadius { get; set; } // 内半径（用于环形图）
            public double Pushout { get; set; } // 扇形突出距离
        }

        public class SeriesVisualStyle
        {
            public string ColorHex { get; set; } = "#4CAF50";
            public LineStyle LineStyle { get; set; } = LineStyle.Solid;
            public double StrokeWidth { get; set; } = 2;
            public double FillOpacity { get; set; } = 0.5;
            public bool ShowMarkers { get; set; } = true;
        }

        public enum LineStyle { Solid, Dashed, Dotted }
    }
}
