﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Models
{
    // Core/Models/DrillDownContext.cs
    public class DrillDownContext
    {
        public required string Dimension { get; set; }  // 当前钻取维度（如"Region"）
        public object? CurrentValue { get; set; }      // 当前选中值（如"华东"）
        public int DrillLevel { get; set; }            // 钻取深度（0=最上层）
        public List<DrillPathItem> Path { get; } = new(); // 钻取路径历史

        public record DrillPathItem(string Dimension, object Value);
    }

 

    public class DrillDownConfig
    {
        public bool Enabled { get; set; }
        public string[] DrillDimensions { get; set; } = []; // 可钻取的维度层级（如["Region","City","Store"]）
    }
}
