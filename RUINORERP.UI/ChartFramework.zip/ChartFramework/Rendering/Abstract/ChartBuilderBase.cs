﻿using LiveChartsCore;
using LiveChartsCore.Kernel.Sketches;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Painting;
using LiveChartsCore.SkiaSharpView.VisualElements;
using LiveChartsCore.SkiaSharpView.WinForms;
using RUINORERP.UI.ChartAnalyzer;
using RUINORERP.UI.ChartFramework.Data.Interfaces;
using RUINORERP.UI.ChartFramework.Extensions.Theming;
using RUINORERP.UI.ChartFramework.Models;
using RUINORERP.UI.ChartFramework.Rendering.Interfaces;
using SkiaSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Rendering.Abstract
{
    // Rendering/Abstract/ChartBuilderBase.cs
    /// <summary>
    /// 图表构建器基类
    /// </summary>

    public abstract class ChartBuilderBase : IChartBuilder
    {
        protected readonly IChartDataSource _dataSource;

        protected ChartBuilderBase(IChartDataSource dataSource)
        {
            _dataSource = dataSource;
            InitializeChart();
        }

        protected ChartRequest _currentRequest;
        protected CartesianChart _chart;


        /// <summary>
        /// 可重写的初始化方法
        /// </summary>
        protected virtual void InitializeChart()
        {
            _chart = new CartesianChart
            {
                AnimationsSpeed = TimeSpan.FromMilliseconds(300),
                //Tooltip = new DefaultTooltip(),
                Tooltip = new DefaultTooltip
                {
                    TextSize = 16,
                    BackgroundColor = SKColors.DarkSlateGray
                },

                LegendPosition = LiveChartsCore.Measure.LegendPosition.Right,
                EasingFunction = EasingFunctions.QuadraticOut
            };
        }

        public abstract Task<IChartView> BuildChartAsync(ChartDataSet data);
        /// <summary>
        /// 构建图表主方法
        /// </summary>
        public async Task<CartesianChart> BuildChartAsync(ChartRequest request)
        {
            _currentRequest = request;
            var dataSet = await _dataSource.GetDataAsync(request);

            _chart.XAxes = CreateXAxes(dataSet);
            _chart.YAxes = CreateYAxes(dataSet);
            _chart.Series = CreateSeries(dataSet);

            return _chart;
        }


        /// <summary>
        /// 可重写的坐标轴创建模板方法
        /// </summary>
        protected virtual Axis[] CreateXAxes(ChartDataSet data)
        {
            return new[]
            {
            new Axis
            {
                Labels = data.MetaData.CategoryLabels, // 使用MetaData中的分类标签
                LabelsRotation = 30,
                TextSize = 12,
                SeparatorsPaint = new SolidColorPaint(SKColors.LightGray.WithAlpha(100)),
                NamePaint = new SolidColorPaint(SKColors.DarkGray)
            }
        };
        }
        //protected virtual Axis[] CreateXAxes(ChartDataSet data)
        //{
        //    return new[]
        //    {
        //        new Axis
        //        {
        //            Labels = data.MetaData.PrimaryLabels,
        //            LabelsRotation = 45,
        //            TextSize = 12,
        //            NamePaint = CurrentTheme.AxisTextPaint
        //        }
        //    };
        //}

        //protected virtual Axis[] CreateYAxes(ChartDataSet data)
        //{
        //    return new[] { new Axis { Labeler = value => value.ToString("N0") } };
        //}

        /// <summary>
        /// 可重写的Y轴创建方法
        /// </summary>
        protected virtual Axis[] CreateYAxes(ChartDataSet data)
        {
            return new[]
            {
            new Axis
            {
                Labeler = value => FormatYValue(value),
                ShowSeparatorLines = true,
                SeparatorsPaint = new SolidColorPaint(SKColors.LightGray.WithAlpha(100)),
                NamePaint = new SolidColorPaint(SKColors.DarkGray)
            }
        };
        }

        /// <summary>
        /// 可扩展的Y轴数值格式化方法
        /// </summary>
        protected virtual string FormatYValue(double value)
        {
            return value switch
            {
                > 1000000 => $"{value / 1000000:N1}M",
                > 1000 => $"{value / 1000:N1}K",
                _ => value.ToString("N0")
            };
        }

        /// <summary>
        /// 可重写的系列生成策略
        /// </summary>
        protected abstract IEnumerable<ISeries> CreateSeries(ChartDataSet data);

        /// <summary>
        /// 可选的后期处理钩子方法
        /// </summary>
        protected virtual void PostBuildProcessing()
        {
            // 默认空实现，子类可按需覆盖
        }

        // Rendering/Abstract/ChartBuilderBase.cs
        protected virtual LabelVisual[] CreateVisualElements(ChartDataSet data)
        {
            return new[]
            {
        new LabelVisual
        {
            Text = data.Title,
            TextSize = 16,
            Padding = new LiveChartsCore.Drawing.Padding(15),
            Paint = new SolidColorPaint(SKColors.DarkSlateGray),
            HorizontalAlignment = LiveChartsCore.Drawing.Align.Start,
            VerticalAlignment = LiveChartsCore.Drawing.Align.Start
        }
    };
        }



        protected ChartTheme CurrentTheme { get; private set; } = ChartTheme.DefaultLight;

        public virtual void ApplyTheme(ChartTheme theme)
        {
            CurrentTheme = theme;
        }

      
     
    }
}
