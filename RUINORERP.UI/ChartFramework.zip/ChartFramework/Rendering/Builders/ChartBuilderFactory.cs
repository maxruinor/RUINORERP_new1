﻿using LiveChartsCore.SkiaSharpView.Painting;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SkiaSharp;
using RUINORERP.UI.ChartFramework.Rendering.Interfaces;
using RUINORERP.UI.ChartFramework.Core;
using RUINORERP.UI.ChartFramework.Models.ChartFramework.Core.Models;


namespace RUINORERP.UI.ChartFramework.Rendering.Builders
{
    // 图表构建器工厂
    public static class ChartBuilderFactory
    {
        public static IChartBuilder CreateBuilder(ChartType chartType)
        {
            return chartType switch
            {
                ChartType.Line => new LineChartBuilder(),
                ChartType.Column => new ColumnChartBuilder(),
                ChartType.Pie => new PieChartBuilder(),
                _ => throw new NotSupportedException()
            };
        }
    }

  


   


}
