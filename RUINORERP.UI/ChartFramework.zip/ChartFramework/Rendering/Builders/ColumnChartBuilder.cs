﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


// Rendering/Builders/ColumnChartBuilder.cs
using LiveChartsCore;
using LiveChartsCore.Kernel;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Painting;
using LiveChartsCore.SkiaSharpView.VisualElements;
using LiveChartsCore.SkiaSharpView.WinForms;
using RUINORERP.UI.ChartFramework.Data.Interfaces;
using RUINORERP.UI.ChartFramework.Extensions.UI;
using RUINORERP.UI.ChartFramework.Models;
using RUINORERP.UI.ChartFramework.Rendering.Abstract;
using RUINORERP.UI.ChartFramework.Rendering.WinForms;
using SkiaSharp;
using RUINORERP.UI.ChartFramework.Rendering.Builders;

namespace RUINORERP.UI.ChartFramework.Rendering.Builders
{
    /*
     // 柱状图使用
var columnBuilder = new ColumnChartBuilder();
var columnChart = columnBuilder.Build(salesData);

// 饼图使用
var pieBuilder = new PieChartBuilder();
var pieChart = pieBuilder.Build(statusDistributionData)
.WithDonutOptions(true); // 启用环形图模式
     */
    public class ColumnChartBuilder : ChartBuilderBase
    {
        public ColumnChartBuilder(IChartDataSource dataSource) : base(dataSource) { }

        public  ChartControl Build(ChartDataSet data)
        {
            var chart = new CartesianChart
            {
                Series = CreateSeries(data),
                XAxes = CreateXAxes(data),
                YAxes = CreateYAxes(data),
                Title = CreateTitle(data),
                VisualElements = CreateVisualElements(data)
            };

            return new ChartControl(chart, data)
                .AddExportMenu()
                .WithStackedOptions(data.MetaData.IsStacked);
        }

        protected override IEnumerable<ISeries> CreateSeries(ChartDataSet data)
        {
            return data.Series.Select((series, index) => new ColumnSeries<double>
            {
                Name = series.Name,
                Values = series.Values.ToArray(),
                Fill = new SolidColorPaint(series.Style.ColorHex.ToSKColor()),
                Stroke = null,
                Rx = 3, // 圆角半径
                Ry = 3,
                MaxBarWidth = 30,
                DataLabelsPaint = new SolidColorPaint(SKColors.White),
                DataLabelsPosition = LiveChartsCore.Measure.DataLabelsPosition.Top,
                DataLabelsFormatter = point => FormatValue(point.Model, data)
            }).ToArray();
        }

        protected override Axis[] CreateXAxes(ChartDataSet data)
        {
            return new[]
            {
            new Axis
            {
                Labels = data.MetaData.PrimaryLabels,
                LabelsRotation = 45,
                TextSize = 12
            }
        };
        }

        //protected override Axis[] CreateXAxes(ChartDataSet data)
        //{
        //    return AxisBuilder.BuildAxes(data.MetaData);
        //}


        protected override Axis[] CreateYAxes(ChartDataSet data)
        {
            return new[]
            {
            new Axis
            {
                Labeler = value => FormatLabel(value, data),
                MinStep = data.MetaData.ValueType ==RUINORERP.UI.ChartFramework.Core.ValueType.Currency ? 100 : 1
            }
        };
        }
        private string FormatValue(double value, ChartDataSet data)
        {
            return data.MetaData.ValueType switch
            {
                RUINORERP.UI.ChartFramework.Core. ValueType.Currency => value.ToString("C2"),
                RUINORERP.UI.ChartFramework.Core.ValueType.Percentage => value.ToString("P1"),
                _ => value.ToString("N0")
            };
        }

        private string FormatLabel(double value, ChartDataSet data)
        {
            return data.MetaData.ValueType switch
            {
                Core.ValueType.Currency => (value / 1000).ToString("C0") + "K",
                Core.ValueType.Percentage => value.ToString("P0"),
                _ => value.ToString("N0")
            };
        }

        private LabelVisual CreateTitle(ChartDataSet data)
        {
            return new LabelVisual
            {
                Text = data.Title,
                TextSize = 16,
                Padding = new LiveChartsCore.Drawing.Padding(15),
                Paint = new SolidColorPaint(SKColors.DarkSlateGray)
            };
        }
    }


}

