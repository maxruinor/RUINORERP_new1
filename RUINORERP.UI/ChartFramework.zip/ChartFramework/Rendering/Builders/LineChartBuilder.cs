﻿using LiveChartsCore.Kernel.Sketches;
using LiveChartsCore.SkiaSharpView.Painting;
using LiveChartsCore.SkiaSharpView.WinForms;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore;
using RUINORERP.UI.ChartAnalyzer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RUINORERP.UI.ChartFramework.Rendering.WinForms;
using RUINORERP.UI.ChartFramework.Rendering.Abstract;
using RUINORERP.UI.ChartFramework.Models;
using RUINORERP.UI.ChartFramework.Models.ChartFramework.Core.Models;
using RUINORERP.Common.Extensions;
using RUINORERP.UI.ChartFramework.Extensions.Theming;

namespace RUINORERP.UI.ChartFramework.Rendering.Builders
{
    // Rendering/Builders/LineChartBuilder.cs

    // 折线图构建器示例
    public class LineChartBuilder : ChartBuilderBase
    {

        private ISeries CreateSeries(ChartSeries series)
        {
            return new LineSeries<double>
            {
                Name = series.Name,
                Values = series.Values.ToArray(),
                Stroke = new SolidColorPaint(ColorHelper.HexToSKColor(series.Style.ColorHex), series.Style.StrokeWidth.ToLong()),
                Fill = null
            };
        }

        public override ChartControl Build(ChartDataSet data)
        {
            var chart = new CartesianChart
            {
                Series = data.Series.Select(CreateSeries).ToArray(),
                XAxes = new[] { new Axis { Labels = data.MetaData.PrimaryLabels } },
                YAxes = new[] { new Axis { Labeler = FormatLabel } }
            };

            return new ChartControl(chart, data);
        }

        private static string FormatLabel(double value)
        {
            return value switch
            {
                >= 1000000 => $"{value / 1000000:F1}M",
                >= 1000 => $"{value / 1000:F1}K",
                _ => value.ToString("N0")
            };
        }

        public override Task<IChartView> BuildChartAsync(ChartDataSet data)
        {
            var chart = new CartesianChart
            {
                XAxes = CreateXAxes(data),
                YAxes = CreateYAxes(data),
                Series = CreateSeries(data),
                Title =data.Title
            };

            return Task.FromResult<IChartView>(chart);
        }

        protected override IEnumerable<ISeries> CreateSeries(ChartDataSet data)
        {
            return data.Series.Select(series => new LineSeries<double>
            {
                Name = series.Name,
                Values = series.Values.ToArray(),
                Stroke = new SolidColorPaint(series.Style.ColorHex.ToSKColor(), series.Style.StrokeWidth.ToLong()),
                Fill = new SolidColorPaint(series.Style.ColorHex.ToSKColor().WithAlpha((byte)(255 * series.Style.FillOpacity))),
                GeometryStroke = null,
                GeometryFill = null,
                LineSmoothness = 0.8
            }).ToArray();
        }
      
    }
}

