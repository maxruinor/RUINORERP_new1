﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using global::RUINORERP.UI.ChartFramework.Models;
using global::RUINORERP.UI.ChartFramework.Rendering.Abstract;
// Rendering/Builders/PieChartBuilder.cs
using LiveChartsCore;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Painting;
using LiveChartsCore.SkiaSharpView.VisualElements;
using LiveChartsCore.SkiaSharpView.WinForms;
using RUINORERP.UI.ChartFramework.Rendering.WinForms;
using SkiaSharp;


namespace RUINORERP.UI.ChartFramework.Rendering.Builders
{
    public class PieChartBuilder : ChartBuilderBase
    {
        public override ChartControl Build(ChartDataSet data)
        {
            var chart = new PieChart
            {
                Series = CreateSeries(data),
                Title = data.Title,
                InitialRotation = -15,
                AnimationsSpeed = TimeSpan.FromSeconds(1),
                VisualElements = CreateVisualElements(data)
            };

            return new ChartControl(chart, data)
                .WithPieContextMenu()
                .WithDonutOptions(data.MetaData.Is100PercentStack);
        }

        protected override IEnumerable<ISeries> CreateSeries(ChartDataSet data)
        {
            // 饼图通常只显示第一个系列
            var series = data.Series.FirstOrDefault();
            if (series == null) return new ISeries[0];

            return new ISeries[]
            {
                new PieSeries<double>
                {
                    Name = series.Name,
                    Values = series.Values.ToArray(),
                    DataLabelsPaint = new SolidColorPaint(SKColors.White),
                    DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                    DataLabelsFormatter = point =>
                        $"{point.Context.Series.Name}: {FormatValue(point.StackedValue.Share, data)}",
                    ToolTipLabelFormatter = point =>
                        $"{point.Context.Series.Name}\n" +
                        $"数值: {point.StackedValue.Total:N0}\n" +
                        $"占比: {point.StackedValue.Share:P1}",
                   // Fill =  null,
                    InnerRadius = 0 // 默认为实心饼图
                }
            };
        }

        private SKColor GetColorForIndex(int index)
        {
            // 使用预设颜色轮转
            var colors = new[]
            {
                SKColor.Parse("#4285F4"), // Blue
                SKColor.Parse("#EA4335"), // Red
                SKColor.Parse("#FBBC05"), // Yellow
                SKColor.Parse("#34A853"), // Green
                SKColor.Parse("#673AB7")  // Purple
            };
            return colors[index % colors.Length];
        }

        private string FormatValue(double value, ChartDataSet data)
        {
            return data.MetaData.ValueType switch
            {
                Core.ValueType.Percentage => value.ToString("P1"),
                Core.ValueType.Currency => value.ToString("C2"),
                _ => value.ToString("N2")
            };
        }
    }

    // 扩展方法
    public static class PieChartExtensions
    {
        public static ChartControl WithDonutOptions(this ChartControl chart, bool isDonut)
        {
            if (isDonut && chart.ChartView is PieChart pieChart)
            {
                foreach (var series in pieChart.Series.Cast<PieSeries<double>>())
                {
                    series.InnerRadius = 60; // 设置内半径创建环形图
                    series.DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Outer;
                }
            }
            return chart;
        }

        public static ChartControl WithPieContextMenu(this ChartControl chart)
        {
            chart.AddMenuItem("高亮扇区", ds =>
            {
                // 实现扇区高亮逻辑
            });
            chart.AddMenuItem("分离扇区", ds =>
            {
                // 实现扇区分离效果
            });
            return chart;
        }
    }
}

