﻿using LiveChartsCore.Kernel.Sketches;
using LiveChartsCore.SkiaSharpView;
using RUINORERP.UI.ChartFramework.Extensions.Theming;
using RUINORERP.UI.ChartFramework.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RUINORERP.UI.ChartFramework.Rendering.Interfaces
{
    // Rendering/Interfaces/IChartBuilder.cs

    public interface IChartBuilder
    {
        Task<IChartView> BuildChartAsync(ChartDataSet data);


        void ApplyTheme(ChartTheme theme);
    }


}
