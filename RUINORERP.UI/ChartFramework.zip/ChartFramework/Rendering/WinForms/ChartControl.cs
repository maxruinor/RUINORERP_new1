﻿using LiveChartsCore.Kernel.Sketches;
using LiveChartsCore.SkiaSharpView.WinForms;
using Org.BouncyCastle.Asn1.Crmf;
using RUINORERP.UI.ChartFramework.Extensions.Export;
using RUINORERP.UI.ChartFramework.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.Integration;

namespace RUINORERP.UI.ChartFramework.Rendering.WinForms
{
    // Rendering/WinForms/ChartControl.cs
    public class ChartControl : UserControl
    {
        private readonly IChartView _chartView;
        private readonly ChartDataSet _dataSet;
        private readonly ContextMenuStrip _menu;

        public IChartView ChartView { get; internal set; }

        public ChartControl(IChartView chartView, ChartDataSet dataSet)
        {
            _chartView = chartView;
            _dataSet = dataSet;

            // 创建宿主控件
            var host = new ElementHost
            {
                Dock = DockStyle.Fill,
                Child = new CartesianChartHost(_chartView)
            };
            Controls.Add(host);

            // 初始化右键菜单
            _menu = new ContextMenuStrip();
            AddDefaultMenuItems();

            // 绑定事件
            host.MouseClick += (s, e) => {
                if (e.Button == MouseButtons.Right)
                    _menu.Show(this, e.Location);
            };
        }

        private void AddDefaultMenuItems()
        {
            _menu.Items.Add("导出Excel", null, (s, e) => {
                using var dialog = new SaveFileDialog
                {
                    Filter = "Excel文件|*.xlsx",
                    FileName = _dataSet.Title + ".xlsx"
                };

                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    _dataSet.ExportToExcel(dialog.FileName);
                    MessageBox.Show("导出成功!");
                }
            });

            _menu.Items.Add("复制数据", null, (s, e) => {
                var dt = _dataSet.ToDataTable();
                Clipboard.SetDataObject(dt);
            });
        }

        public void AddMenuItem(string text, Action<ChartDataSet> action)
        {
            _menu.Items.Add(text, null, (s, e) => action(_dataSet));
        }
    }
}
